"""
Vercel Serverless Function Entrypoint: /api/index.py
Allows Vercel to route serverless API requests or serve as the Flask WSGI entrypoint.
"""
import sys
import os

# Add root directory to sys.path
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from app import app

# Export app for Vercel WSGI
__all__ = ["app"]
